﻿$(document).ready(function () {
    bindEvents();
  
    
});

function bindEvents() {

    //employeebyId
  
    $(".employeeDetails").on("click", function (event) {
        var employeeId = event.currentTarget.getAttribute("data-id");

        $.ajax({
            url: 'https://localhost:6001/api/getemployees/' + employeeId,
            type: 'GET',
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                $("#displayname").html("<b>NAME:</b>  " + result.name);
                $("#displaydepartment").html("<b>DEPARTMENT:</b>   " + result.department);
                $("#displayage").html("<b>AGE:</b>    " + result.age);
                $("#displayaddress").html("<b>ADDRESS:</b>   " + result.address);
            },
            error: function (error) {
                console.log(error);
            }
        });

    });

    //insert 

    $("#createform").submit(function (event) {

        var employeeDetailedViewModel = {};

        employeeDetailedViewModel.Name = $("#name").val();
        employeeDetailedViewModel.Department = $("#department").val();
        employeeDetailedViewModel.Age = Number($("#age").val());
        employeeDetailedViewModel.Address = $("#address").val();

        var data = JSON.stringify(employeeDetailedViewModel);

        $.ajax({
            url: 'https://localhost:6001/api/getemployees',
            type: 'POST',
            dataType: "application/json; charset=utf-8",
            contentType: "application/json; charset=utf-8",
            data: data,
            success: function (result) {
                location.reload();
            },
            error: function (error) {
                console.log(error);
            }
        });

        alert("INSERT SUCCESSFULL");

    });

    //update

    $(".employeeEdit").on("click", function (event) {

        var employeeId = event.currentTarget.getAttribute("data-id");

        $.ajax({
            url: 'https://localhost:6001/api/getemployees/' + employeeId,
            type: 'GET',
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                    $("#updateName").val(result.name)
                    $("#updateDepartment").val(result.department)
                    $("#updateAge").val(result.age)
                    $("#updateAddress").val(result.address) 
            },
            error: function (error) {
                console.log(error);
            }
        });   

    $("#updateform").submit(function (event) {

        var employeeDetailedViewModel = {};

        employeeDetailedViewModel.Name = $("#updateName").val();
        employeeDetailedViewModel.Department = $("#updateDepartment").val();
        employeeDetailedViewModel.Age = Number($("#updateAge").val());
        employeeDetailedViewModel.Address = $("#updateAddress").val();

        var data = JSON.stringify(employeeDetailedViewModel);

        $.ajax({
            url: 'https://localhost:6001/api/getemployees/' + employeeId,
            type: 'PUT',
            dataType: "application/json; charset=utf-8",
            contentType: "application/json; charset=utf-8",
            data: data,
            success: function (result) {
                location.reload();
            },
            error: function (error) {
                console.log(error);
            }
        });

        alert("UPDATE SUCCESSFULL");
    });

    });

    //delete

    $(".employeeDelete").on("click", function (event) {

        var employeeId = event.currentTarget.getAttribute("data-id");

        var confirmdelete = confirm("CONFIRM DELETE");

        if (confirmdelete) {
            $.ajax({
                url: 'https://localhost:6001/api/getemployees/' + employeeId,
                type: 'DELETE',
                contentType: "application/json; charset=utf-8",
                success: function (result) {
                    location.reload();
                },
                error: function (error) {
                    console.log(error);
                }
            });
            alert("DELETE SUCESSFULLY");
        }        
    });
}



