﻿using EmployeeManagement.UI.Models;
using EmployeeManagement.UI.Models.Provider;
using EmployeeManagement.UI.Providers.Contracts;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace EmployeeManagement.UI.Providers.ApiClients
{
    public class EmployeeApiClient : IEmployeeApiClient
    {
        private readonly HttpClient _httpClient;

        public EmployeeApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public IEnumerable<EmployeeViewModel> GetAllEmployee()
        {
            var response = _httpClient.GetAsync("https://localhost:5001/api/employees").Result;

            var employeeResponse = response.Content.ReadAsStringAsync().Result;

            var employee = JsonConvert.DeserializeObject<IEnumerable<EmployeeViewModel>>(employeeResponse);

            return (employee);
           
        }

        public EmployeeDetailedViewModel GetEmployeeById(int id)
        {
            var response = _httpClient.GetAsync($"https://localhost:5001/api/employees/{id}").Result;

            var employeeResponse = response.Content.ReadAsStringAsync().Result;

            var employee = JsonConvert.DeserializeObject<EmployeeDetailedViewModel>(employeeResponse);

            return (employee);

        }

        public bool InsertEmployee(EmployeeDetailedViewModel employeeDetailedView)
        {

            var content = new StringContent(JsonConvert.SerializeObject(employeeDetailedView), Encoding.UTF8, "application/json");

            var response = _httpClient.PostAsync("https://localhost:5001/api/employees", content).Result;

            return true;

        }

        public bool UpdateEmployee(EmployeeDetailedViewModel employeeDetailedView)
        {
            var content = new StringContent(JsonConvert.SerializeObject(employeeDetailedView),Encoding.UTF8, "application/json");

            var response = _httpClient.PutAsync("https://localhost:5001/api/employees",content).Result;

            return true;


        }
        public bool DeleteEmployee(int id)
        {

            var content = new StringContent(JsonConvert.SerializeObject(id));

            var response = _httpClient.DeleteAsync($"https://localhost:5001/api/employees/{id}").Result;

            return true;


        }
    }
}
