﻿using EmployeeManagement.DataAccess.Models;
using EmployeeManagement.UI.Models;
using EmployeeManagement.UI.Providers.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.UI.Controllers.InternalAPI
{
    [Route("api/getemployees")]
    [ApiController]
    public class EmployeeInternalApiController : ControllerBase
    {
        private readonly IEmployeeApiClient _employeeApiClient;

        public EmployeeInternalApiController(IEmployeeApiClient employeeApiClient)
        {
            _employeeApiClient = employeeApiClient;
        }

        [HttpGet]

        [Route("{employeeId}")]

        public IActionResult GetEmployeeById([FromRoute] int employeeId)
        {
            try
            {
                var employee = _employeeApiClient.GetEmployeeById(employeeId);

                return Ok(employee);
               
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpPost]

        public IActionResult InsertEmployeeDetail([FromBody]EmployeeData employeeData)
        {
            try
            {
                var employee = _employeeApiClient.InsertEmployee(MaptoInsert(employeeData));

                return StatusCode(StatusCodes.Status200OK);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        private EmployeeDetailedViewModel MaptoInsert(EmployeeData employeeData)
        {
            var employee = new EmployeeDetailedViewModel
            {
                Id = employeeData.Id,
                Name = employeeData.Name,
                Age = employeeData.Age,
                Department = employeeData.Department,
                Address = employeeData.Address
            };

            return employee;
        }

        [HttpPut]
         
        [Route ("{employeeId}")]
        public IActionResult UpdateEmployeeDetail([FromBody] EmployeeData employeeData, [FromRoute]int employeeId)
        {
            try
            {
                employeeData.Id = employeeId;

                var employee = _employeeApiClient.UpdateEmployee(MaptoUpdate(employeeData));

                return StatusCode(StatusCodes.Status200OK);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);

            }
        }

        private EmployeeDetailedViewModel MaptoUpdate(EmployeeData employeeData)
        {
            var employee = new EmployeeDetailedViewModel
            {
                Id = employeeData.Id,
                Name = employeeData.Name,
                Age = employeeData.Age,
                Department = employeeData.Department,
                Address = employeeData.Address
            };

            return employee;
        }

        [HttpDelete]

        [Route("{employeeId}")]

        public IActionResult DeleteEmployeeDetail([FromRoute] int employeeId)
        {
            try
            {
                var employee = _employeeApiClient.DeleteEmployee(employeeId);

                return StatusCode(StatusCodes.Status200OK);


            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }
            
    }
}
