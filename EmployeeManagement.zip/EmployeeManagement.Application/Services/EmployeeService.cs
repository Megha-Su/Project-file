﻿using EmployeeManagement.Application.Contracts;
using EmployeeManagement.Application.Models;
using EmployeeManagement.DataAccess.Contracts;
using EmployeeManagement.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeManagement.Application.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeService(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public EmployeeDto GetEmployeeById(int id)
        {
            try
            {
                var employeeDetail = _employeeRepository.GetEmployeeById(id);

                
                return MapToEmployeeId(employeeDetail);

            }
            catch (Exception)
            {
                throw;
            }
          
        }
        private EmployeeDto MapToEmployeeId(DataAccess.Models.EmployeeData employeeDetail)
        {
            var employee = new EmployeeDto
            {
                Id = employeeDetail.Id,
                Name = employeeDetail.Name,
                Age = employeeDetail.Age,
                Department = employeeDetail.Department,
                Address = employeeDetail.Address
            };

            return employee;
        }
        public IEnumerable<EmployeeDto> GetEmployees()
        {
            try
            {
                var employeeDetails = _employeeRepository.GetEmployees();

                var listEmployeeDto = employeeDetails.Select(employee => new EmployeeDto
                {
                    Id = employee.Id,
                    Name = employee.Name,
                    Age =  employee.Age,
                    Department = employee.Department,
                    Address = employee.Address,
                });
                return listEmployeeDto;
            }
            catch (Exception)
            {
                throw;
            }
              
        }
        public bool InsertEmployeeDetail(EmployeeDto employeeDto)
        {
            try
            {
                var employeeInsert = _employeeRepository.InsertEmployee(MapToEmployee(employeeDto));

                return employeeInsert;
            }
            catch (Exception)
            {
                throw;
            }           
        } 
        public bool UpdateEmployeeDetail(EmployeeDto employeeDto)
        {
            try
            {
                var employeeUpdate = _employeeRepository.UpdateEmployee(MapToEmployee(employeeDto));

                return employeeUpdate;
            }
            catch (Exception)
            {
                throw;
            }      
        }
        private DataAccess.Models.EmployeeData MapToEmployee(EmployeeDto employeeDto)
        {
            var employee = new EmployeeData
            {
                Id = employeeDto.Id,
                Name = employeeDto.Name,
                Age = employeeDto.Age,
                Department = employeeDto.Department,
                Address = employeeDto.Address
            };
            return employee;
        }
        public bool DeleteEmployeeDetail(int id)
        {
            try
            {
                var employeeDelete = _employeeRepository.DeleteEmployee(id);

                return employeeDelete;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
