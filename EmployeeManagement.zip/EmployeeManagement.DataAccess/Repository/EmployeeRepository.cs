﻿using EmployeeConfiguration;
using EmployeeManagement.DataAccess.Contracts;
using EmployeeManagement.DataAccess.Models;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace EmployeeManagement.DataAccess.Repository
{

    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly SqlConnection sqlConnection;
     

        public EmployeeRepository(IOptions<ConnectionString> connectionStringOption)
        {
            
            var connectionString = connectionStringOption.Value;

            sqlConnection = new SqlConnection(connectionString.EmployeeDb);

        }
        public EmployeeData GetEmployeeById(int id)
        {
            try
            {
                sqlConnection.Open();

                var sqlCommand = new SqlCommand("SELECT * FROM  EmployeeDetailsTable WHERE Id=@Id", sqlConnection);

                sqlCommand.Parameters.AddWithValue("Id", id);

                var sqlDataRead = sqlCommand.ExecuteReader();

                var employeeList = new List<EmployeeData>();

                while (sqlDataRead.Read())
                {
                    employeeList.Add(new EmployeeData
                    {
                        Id = (int)sqlDataRead["Id"],
                        Name = (string)sqlDataRead["Name"],
                        Department = (string)sqlDataRead["Department"],
                        Age = (int)sqlDataRead["Age"],
                        Address = (string)sqlDataRead["Address"]
                    });
                }

                return employeeList.FirstOrDefault();
            }

            catch (Exception)
            {
                throw;

            }
            finally
            {
                sqlConnection.Close();
            }

        }
        public IEnumerable<EmployeeData> GetEmployees()
        {
            try
            {
                sqlConnection.Open();

                SqlCommand sqlCommand = new SqlCommand("SELECT * FROM  EmployeeDetailsTable  ", sqlConnection);

                var employeeList = new List<EmployeeData>();

                var sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    employeeList.Add(new EmployeeData
                    {
                        Id = (int)sqlDataReader["Id"],
                        Name = (string)sqlDataReader["Name"],
                        Department = (string)sqlDataReader["Department"],
                        Age = (int)sqlDataReader["Age"],
                        Address = (string)sqlDataReader["Address"]
                    });
                }

                return employeeList;

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }

        }
        public bool InsertEmployee(EmployeeData employeeData)
        {
            try
            {
                sqlConnection.Open();

                var sqlCommand = new SqlCommand("Insert into EmployeeDetailsTable values (@Name,@Department,@Age,@Address)", sqlConnection);

                sqlCommand.Parameters.AddWithValue("Name", employeeData.Name);

                sqlCommand.Parameters.AddWithValue("Department", employeeData.Department);

                sqlCommand.Parameters.AddWithValue("Age", employeeData.Age);

                sqlCommand.Parameters.AddWithValue("Address", employeeData.Address);

                sqlCommand.ExecuteNonQuery();

                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }

        }
        public bool UpdateEmployee(EmployeeData employeeData) 
        {
            try
            {
                sqlConnection.Open();

                var sqlCommand = new SqlCommand("UPDATE EmployeeDetailsTable SET Name=@Name,Department=@Department,Age=@Age,Address=@Address WHERE Id=@Id", sqlConnection);

                sqlCommand.Parameters.AddWithValue("Id", employeeData.Id);

                sqlCommand.Parameters.AddWithValue("Name", employeeData.Name);

                sqlCommand.Parameters.AddWithValue("Age", employeeData.Age);

                sqlCommand.Parameters.AddWithValue("Department", employeeData.Department);

                sqlCommand.Parameters.AddWithValue("Address", employeeData.Address);

                sqlCommand.ExecuteNonQuery();

                return true;
            }

            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConnection.Close();
            }

        }
        public bool DeleteEmployee(int id)
        {
                try
                {
                    sqlConnection.Open();

                    var sqlCommand = new SqlCommand("DELETE FROM EmployeeDetailsTable WHERE Id=@Id;", sqlConnection);

                    sqlCommand.Parameters.AddWithValue("Id", id);

                    sqlCommand.ExecuteNonQuery();

                    return true;
                }

                catch
                {
                    throw;
                }

                finally
                {
                    sqlConnection.Close();
                }
            
        }
    }
}     
    
