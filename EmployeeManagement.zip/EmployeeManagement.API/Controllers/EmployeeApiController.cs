﻿using EmployeeManagement.API.Models;
using EmployeeManagement.Application.Contracts;
using EmployeeManagement.Application.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeManagement.API.Controllers
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeeApiController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeApiController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpGet]
        [Route("{employeeId}")]
        public IActionResult GetEmployeeById([FromRoute] int employeeId)
        {
            try
            {

                var employeeById = _employeeService.GetEmployeeById(employeeId);

                return Ok(employeeById);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet]
    
        public IActionResult GetEmployees()
        {
            try
            {
                var employees = _employeeService.GetEmployees();
                
                return Ok(employees);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }


        }
        [HttpPost]
        
        public IActionResult InsertEmployees([FromBody] EmployeeDetailedViewModel employeeDetailedView)
        {
            try
            {
                var insertEmployee = _employeeService.InsertEmployeeDetail(MapToEmployee(employeeDetailedView));

                return StatusCode(StatusCodes.Status200OK);
            }
            catch (Exception)  
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpPut]

       
        public IActionResult UpdateEmployees([FromBody] EmployeeDetailedViewModel employeeDetailedView)
        {
            try
            {

                var updateEmployee = _employeeService.UpdateEmployeeDetail(MapToEmployee(employeeDetailedView));

                return StatusCode(StatusCodes.Status200OK);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }
        
        private Application.Models.EmployeeDto MapToEmployee(EmployeeDetailedViewModel employeeDetailedView)
        {
            var employee = new EmployeeDto
            {
                Id = employeeDetailedView.Id,
                Name = employeeDetailedView.Name,
                Age = employeeDetailedView.Age,
                Department = employeeDetailedView.Department,
                Address = employeeDetailedView.Address

            };
            return employee;
        }

        [HttpDelete]

        [Route("{id}")]

        public IActionResult DeleteEmployees([FromRoute]int id)
        {
            try
            {
                var deleteEmployee = _employeeService.DeleteEmployeeDetail(id);

                return StatusCode(StatusCodes.Status200OK);

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            } 
        }
    }   
}
