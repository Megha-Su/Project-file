﻿using System;

namespace EmployeeConfiguration
{
    public class ConnectionString
    {
        public string EmployeeDb { get; set; }
    }
}
